/** Programa básico en java
 * para hacer cálculos matemáticos
 * se usa switch case y trabaja con decimales
 */

import java.util.Scanner;

public class Calculadora {
// uso de la clase Scanner para leer valores de entrada
    static Scanner scan = new Scanner(System.in);

    //uso de main para ejecutar el programa
    public static void main(String[] args) {


        Scanner lector = new Scanner(System.in);
        double x;
        double y;
        System.out.println("Ingrese el número A:");
        // uso de nextDouble para la lectura de tipo double
        x = lector.nextDouble();
        System.out.println("Ingrese el número B:");
        y = lector.nextDouble();
        System.out.println("Ingrese el tipo de operacion:");
        String operaciones = scan.next () ;


        // devolver los valores de char a partir de cero
        char calculos = operaciones.charAt ( 0 ) ;
        switch(calculos){
            case 'S': case 's':double s; s=(x+y); System.out.println("La suma es:" +s); break;
            case 'R': case 'r':double r; r=(x-y); System.out.println("La resta es:" +r); break;
            case 'M': case 'm':double m; m=(x*y); System.out.println("La multiplicación es:" +m); break;
            case 'D': case 'd':double d; d=(x/y); System.out.println("La division es:" +d); break;
            default: System.out.println(" No se puede hacer la operacion ");
        }
    }
}
