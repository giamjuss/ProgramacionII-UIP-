package com.example.conctacappgiam;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.conctacappgiam.basedatos.contactoContruyendo;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    ListView lvContactos;
    ArrayList<Contacto> contactos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvContactos= (ListView) findViewById(R.id.lvContactos);
        contactos = new ArrayList<>();
        contactoContruyendo contactoContruyendo = new contactoContruyendo ();
        contactos= contactoContruyendo.mostrardatos(this);



        ArrayList<String> nombreContactos = new ArrayList<>();

        for(Contacto contacto: contactos){
            nombreContactos.add(contacto.getNombre());

        }
        lvContactos.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,nombreContactos));
        lvContactos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> AdapterView, View view, int posicion, long l) {
                Intent intent = new Intent(MainActivity.this,DetalleContactoActivity.class);
                intent.putExtra("ClaveNombre",contactos.get(posicion).getNombre());
                intent.putExtra("ClaveTelefono",contactos.get(posicion).getApellido());
                intent.putExtra("ClaveDireccion",contactos.get(posicion).getTelefono());
                startActivity(intent);

            }


        });
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
        != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.CALL_PHONE},12);
        }

      }
      @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int [] grantResult)
      {
          super.onRequestPermissionsResult(requestCode, permissions, grantResult);
          switch (requestCode){
              case 12 : {
                  if (grantResult.length > 0 && grantResult[0] == PackageManager.PERMISSION_GRANTED){
                      Toast.makeText(this, "Se otorgo el permiso de llamadas", Toast.LENGTH_SHORT).show();

                  } else {
                      Toast.makeText(this, "Rechazo el permiso de llamadas", Toast.LENGTH_SHORT).show();
                  }
                  return;
              }
          }
      }
}
