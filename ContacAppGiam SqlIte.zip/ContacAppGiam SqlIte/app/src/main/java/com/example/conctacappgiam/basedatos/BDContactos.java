package com.example.conctacappgiam.basedatos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import com.example.conctacappgiam.Contacto;

import java.util.ArrayList;

class BDContacto extends SQLiteOpenHelper {
    Context context;
    public BDContacto(Context context) {
        super(context, "contactos", null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String queryCrearTablaContacto = "CREATE TABLE contacto (id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                                                                         "nombre TEXT," +
                                                                                       "apellido TEXT," +
                                                                                      " telefono TEXT)";
        sqLiteDatabase.execSQL (queryCrearTablaContacto);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public ArrayList<Contacto> obtenerContactos (){
        ArrayList<Contacto>contactos = new ArrayList<>();
        String queryGetContactos = "SELECT * FROM contacto";
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(queryGetContactos,null);
        while (cursor.moveToNext() ){
            Contacto contacto = new Contacto();
            contacto.setId(cursor.getInt(0));
            contacto.setNombre(cursor.getString(1));
            contacto.setApellido(cursor.getString(2));
            contacto.setTelefono(cursor.getInt(3));
            contactos.add(contacto);





        }
        sqLiteDatabase.close();
        return contactos;
    }
    public void insertarContactos(ContentValues contentValues){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.insert("contacto", null,contentValues );
        sqLiteDatabase.close();

    }
}
