package com.example.conctacappgiam.basedatos;


import android.content.ContentValues;
import android.content.Context;

import com.example.conctacappgiam.Contacto;
import java.util.ArrayList;


public class contactoContruyendo {
    ArrayList<Contacto>contactos;
    Context context;
    public ArrayList<Contacto> mostrardatos(Context context) {
        this.context = context;
        contactos= new ArrayList<>();
        BDContacto Bd = new BDContacto(context);
        insertarVariosContactos(Bd);
       contactos = Bd.obtenerContactos ();
       return contactos;

    }
    public void insertarVariosContactos (BDContacto Bd){
        ContentValues contentValues = new ContentValues();
        contentValues.put("nombre","Kenny");
        contentValues.put("apellido","Vargas");
        contentValues.put("telefono","60459365");
        Bd.insertarContactos(contentValues);

        contentValues = new ContentValues();
        contentValues.put("nombre","Kyle");
        contentValues.put("apellido","Martin");
        contentValues.put("telefono","60459365");
        Bd.insertarContactos(contentValues);

        contentValues = new ContentValues();
        contentValues.put("nombre","Cartman");
        contentValues.put("apellido","Perez");
        contentValues.put("telefono","60459365");
        Bd.insertarContactos(contentValues);

        contentValues = new ContentValues();
        contentValues.put("nombre","Stan");
        contentValues.put("apellido","Diaz");
        contentValues.put("telefono","60459365");
        Bd.insertarContactos(contentValues);



    }


}
