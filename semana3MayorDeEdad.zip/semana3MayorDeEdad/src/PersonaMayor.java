
import java.util.Scanner;


public class PersonaMayor {
    private Scanner teclado;

    private String nombre;

    private int edad;
    private String materia1;
    private String materia2;


    public void inicializar(){
        teclado=new Scanner (System.in);
        System.out.println("Ingrese el nombre :");
        nombre=teclado.next();
        System.out.println("Ingrese la edad : ");
        edad=teclado.nextInt();
        System.out.print("Ingrese materia 1: ");
        materia1=teclado.next();
        System.out.print("Ingrese materia 2 : ");
        materia2=teclado.next();


    }

    public void imprimir(){
        System.out.println("Nombre: "+ nombre);
        System.out.println("Edad:"+ edad);
    }

    public void esMayorEdad(){
        if(edad>=18){
            System.out.print(nombre+ "Es mayor de edad ");

        }else {
            System.out.print(nombre+ "No es mayor de edad ");
        }

    }

    public void CodigoMateria1(){
        if(materia1.contentEquals("500-00456")){
            System.out.println("Cumple Prerequisito"+materia1);
        }else {
            System.out.println("No cumple con el Prerequisto 500-00456 de ingreso"+materia1);
        }
    }


    public void CodigoMateria2(){
        if(materia2.contentEquals("500-00460")){
            System.out.println("Cumple Prerequisito"+materia2);
        }else {
            System.out.println("No cumple con el Prerequisto 500-00456 de ingreso"+materia2);
        }
    }

    public static void main(String[]arg) {
        PersonaMayor persona1;
        persona1=new PersonaMayor();
        persona1.inicializar();
        persona1.imprimir();
        persona1.esMayorEdad();
        persona1.CodigoMateria1();
        persona1.CodigoMateria2();

    }
}
